//Checkout constants
export const address = "Address";
export const payment = "Payment"
export const review = "Review";